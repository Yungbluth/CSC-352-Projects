#include <stdlib.h>
#include <stdio.h>


void *my_firstfit_malloc(unsigned int size);
void my_free(void *p);
